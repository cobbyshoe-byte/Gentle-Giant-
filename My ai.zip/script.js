const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const chatLog = document.getElementById('chat-log');

const apiKey = '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';
const apiEndpoint = 'https:                                      

sendBtn.addEventListener('//api.openai.com/v1/chat/completions';

sendBtn.addEventListener('click', async () => {
    const userMessage = userInput.value.trim();
    if (userMessage) {
        const userChatMessage = document.createElement('div');
        userChatMessage.classList.add('user-message');
        userChatMessage.textContent = userMessage;
        chatLog.appendChild(userChatMessage);

        const response = await getAIResponse(userMessage);
        const aiChatMessage = document.createElement('div');
        aiChatMessage.classList.add('ai-response');
        aiChatMessage.textContent = response;
        chatLog.appendChild(aiChatMessage);

        userInput.value = '';
    }
});

async function getAIResponse(prompt) {
    const response = await fetch(apiEndpoint, {
        method: 'function getAIResponse(prompt) {
    const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.7,
        }),
    });

    const data = await response.json();
    return data.choices[0].message.content;
}